(* Exercice 3 *)
module type Expression = sig
  (* Type pour représenter les expressions *)
  type exp


  (* eval : TO DO *)
  val eval : exp -> int
end

(* Exercice 4 *)

(* TO DO avec l'aide du fichier  expressionArbreBinaire.txt *)

(* Exercice 5 *)

(* TO DO avec l'aide du fichier  expressionArbreNaire.txt *)